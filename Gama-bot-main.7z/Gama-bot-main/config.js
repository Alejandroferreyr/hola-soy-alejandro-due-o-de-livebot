import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'

global.owner = [
  ['5493734486396', 'GamaBot', true],
  ['5493734468429'], 
  ['5493734515483'] 
] //Numeros de owner 

global.mods = ['5493437515483'] 
global.prems = ['5493734515483', '5493734446902']
global.APIs = { // API Prefix
  // name: 'https://website'
  xteam: 'https://api.xteam.xyz', 
  nrtm: 'https://fg-nrtm.onrender.com',
  bg: 'http://bochil.ddns.net',
  fgmods: 'https://api-fgmods.ddns.net'
}
global.APIKeys = { // APIKey Here
  // 'https://website': 'apikey'
  'https://api.xteam.xyz': 'd90a9e986e18778b',
  'https://zenzapis.xyz': '675e34de8a', 
  'https://api-fgmods.ddns.net': 'fg-dylux'
}

// Sticker WM
global.packname = 'Gama┃ᴮᴼᵀ' 
global.author = '@Gama' 
global.fgig = '▢ Sígueme en Instagram\nhttps://www.instagram.com/gama_dioses\n' 
    global.dygp = 'https://chat.whatsapp.com/GbCBIpt0RrhKbDV4aejm2M'
global.fgsc = 'https://github.com/Gamadios/GamaBot-MD-' 
global.fgyt = 'https://youtube.com/EzequielLinux'
global.fgpyp = 'https://paypal.me/'
global.fglog = 'https://i.imgur.com/Owmb93c.png' 

global.wait = '*⌛ _Cargando..._*\n*▰▰▰▱▱▱▱▱*'
global.rwait = '⌛'
global.dmoji = '🤭'
global.done = '✅'
global.error = '❌' 
global.xmoji = '🔥' 

global.multiplier = 69 
global.maxwarn = '2' // máxima advertencias

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})
