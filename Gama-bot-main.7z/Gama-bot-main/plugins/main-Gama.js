
let handler = async (m, { conn }) => {

m.reply(`
≡  *GamaBot-MD ┃ SUPPORT*

◈ ━━━━━━━━━━━━━━━━━━━━ ◈
▢ Grupo *1*
https://chat.whatsapp.com/GbCBIpt0RrhKbDV4aejm2M

▢ Grupo *2*
https://chat.whatsapp.com/ETCA2UKt8vYDpQ6kiQbM3I

▢ Grupo *NSFW* 🔞
https://chat.whatsapp.com/CVEs3jrfjVq7Ahig9C0iVz

◈ ━━━━━━━━━━━━━━━━━━━━ ◈
▢ Todos los Grupos
 *Grande el Dibu*😍🤣

 ▢ *PayPal*
• https://paypal.me/

▢ *YouTube*
• https://www.youtube.com/EzequielLinux`)

}
handler.help = ['support']
handler.tags = ['main']
handler.command = ['grupos', 'groupgama', 'dxgp', 'gmgp', 'gpgama', 'support'] 

export default handler
