
let handler = m => m
handler.all = async function (m) {

    if (/^buenos días$/i.test(m.text) ) {
      let av = 'https://f.top4top.io/m_2437qgtmd1.mp3'
      this.sendFile(m.chat, av, 'audio.mp3', null, m, true, { type: 'audioMessage', ptt: true })
     }

  if (/^buenas tardes$/i.test(m.text) ) {
     let av = 'https://g.top4top.io/m_2437lm0y21.mp3'
     this.sendFile(m.chat, av, 'audio.mp3', null, m, true, { type: 'audioMessage', ptt: true })
   }

  if (/^buenas noches$/i.test(m.text) ) {
    let av = 'https://e.top4top.io/m_2437afchn1.mp3'
    this.sendFile(m.chat, av, 'audio.mp3', null, m, true, { type: 'audioMessage', ptt: true })
   }
   
   if (/^Bienvenido$/i.test(m.text) ) {
    let av = 'https://e.top4top.io/m_2569q9lj80.mp3'
    this.sendFile(m.chat, av, 'audio.mp3', null, m, true, { type: 'audioMessage', ptt: true })
   }
   
      if (/^Baneado$/i.test(m.text) ) {
    let av = 'https://c.top4top.io/m_2569vye0m0.mp3'
    this.sendFile(m.chat, av, 'audio.mp3', null, m, true, { type: 'audioMessage', ptt: true })
   }
   
   
      if (/^Zzz$/i.test(m.text) ) {
    let av = 'https://e.top4top.io/m_25694ahbn1.mp3'
    this.sendFile(m.chat, av, 'audio.mp3', null, m, true, { type: 'audioMessage', ptt: true })
   }
   
     if (/^Bañate$/i.test(m.text) ) {
    let av = 'https://a.top4top.io/m_2569ajjeo0.mp3'
    this.sendFile(m.chat, av, 'audio.mp3', null, m, true, { type: 'audioMessage', ptt: true })
   }
  
  
     if (/^HolaGamaBot$/i.test(m.text) ) {
    let av = 'https://e.top4top.io/m_2569dgmhd0.mp3'
    this.sendFile(m.chat, av, 'audio.mp3', null, m, true, { type: 'audioMessage', ptt: true })
   }
  
     if (/^mmm$/i.test(m.text) ) {
    let av = 'https://j.top4top.io/m_2569be4b80.mp3'
    this.sendFile(m.chat, av, 'audio.mp3', null, m, true, { type: 'audioMessage', ptt: true })
   }
  
  
     if (/^joder$/i.test(m.text) ) {
    let av = 'https://c.top4top.io/m_2569s4dwv0.mp3'
    this.sendFile(m.chat, av, 'audio.mp3', null, m, true, { type: 'audioMessage', ptt: true })
   }
  
  
     if (/^XD$/i.test(m.text) ) {
    let av = 'https://g.top4top.io/m_2569w4t9o0.mp3'
    this.sendFile(m.chat, av, 'audio.mp3', null, m, true, { type: 'audioMessage', ptt: true })
   }
  
  
return !0
 }
 
export default handler
